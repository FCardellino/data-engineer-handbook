## 1. Pipeline Ownership

We have 5 pipelines, and we’re 4 engineers. Best practice is:

Each pipeline has a primary owner (responsible for design, improvements, and responding first if issues occur).

Each pipeline also has a secondary owner (backup, reviewer, and helps if the primary is unavailable).

Here’s a fair allocation:

Pipeline	Primary Owner	Secondary Owner
Profit – Unit-level (experiments)	Engineer A	Engineer B
Profit – Aggregate (investors)	Engineer B	Engineer C
Growth – Aggregate (investors)	Engineer C	Engineer D
Growth – Daily (experiments)	Engineer D	Engineer A
Engagement – Aggregate (investors)	Engineer A	Engineer C

💡 Notice:

Investor-facing pipelines (aggregate metrics) are spread across different primaries.

Experimental pipelines are balanced as “lighter” ownership since they’re less investor-sensitive.

## 2. On-Call Schedule (Fair & Holidays Considered)

We want a weekly rotation with clear backup. For 4 engineers:

- Week 1: Engineer A (primary on-call), Engineer B (backup)

- Week 2: Engineer B (primary on-call), Engineer C (backup)

- Week 3: Engineer C (primary on-call), Engineer D (backup)

- Week 4: Engineer D (primary on-call), Engineer A (backup)

Then repeat.

**Holidays**

If someone is on vacation/holiday, they swap weeks in advance.

Backup always covers if primary is offline unexpectedly.

Investor-reporting pipelines (Profit agg, Growth agg, Engagement agg) have escalation paths to ensure issues are handled even if both are out (escalate to Eng. Manager).

## 3. Runbooks for Investor-Facing Pipelines

These are critical because executives and investors depend on them.
Pipelines:

- Profit – Aggregate

- Growth – Aggregate

- Engagement – Aggregate

**General Runbook Template**

- Pipeline Purpose: What business metric is being calculated.

- Data Sources: Which raw data tables and external APIs feed it.

- Transformations: Key joins, filters, aggregations.

- SLAs: By what time data must be ready (e.g., 8am UTC daily).

**Failure Modes (what can go wrong).**

- Recovery Steps: How to troubleshoot and fix.

- Escalation: Who to notify if SLA is missed.

# Examples: 

**Profit – Aggregate Runbook**

- Purpose: Compute total company profit daily/monthly for investor reports.
Sources:

- Transactions table (orders, refunds).

- Cost data (fulfillment, returns, platform fees).
*Transformations:*

- Profit = Revenue – Costs (per transaction).

- Aggregate by day, month, quarter.

*Failure Modes:*

- Transaction data delayed → profit under-reported.

- Cost data missing for certain regions → inflated profit.

- Schema changes in source tables.

- Late-arriving data from external systems (e.g., refunds after cutoff).

*Recovery Steps:*

- Check DAG logs (Airflow/DBT/etc.).

- Re-run only failed tasks if DAG is partially complete.

- If data missing from source → notify source system team.

- Validate aggregates vs. last known good run.

*Escalation:*

- Primary → Secondary → Data Eng. Manager if unresolved in 2 hours.

**Growth – Aggregate Runbook**

- Purpose: Track new users/customers daily, roll up to monthly growth rate.
*Failure Modes:*

- Duplicate user IDs inflating growth.

- User acquisition events missing.

- Late ingestion from marketing APIs.

*Recovery:*

- Reconcile user IDs vs. historical records.

- Retry API pulls.

- Apply deduplication.

**Engagement – Aggregate Runbook**

- Purpose: Active users (DAU, MAU) and engagement metrics.
Failure Modes:

- Missing event logs from tracking system (Kafka/Segment/etc.).

- Spikes in data due to bad instrumentation.

- Event schema change (e.g., “login” → “user_login”).

*Recovery:*

- Verify ingestion status in logs.

- Cross-check user counts with sample queries.

- Roll back to previous schema mappings if needed.

## Conclusion:
With this, every engineer knows:

- Who owns each pipeline.

- When they’re on-call (and with backup).

- What to do when investor-facing pipelines break.